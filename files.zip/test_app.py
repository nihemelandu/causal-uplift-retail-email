"""Tests for the dashboard. Run with: pytest

The synthetic tables below are for tests ONLY. They are not results.
"""
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from streamlit.testing.v1 import AppTest

import app
from data import (CAMPAIGNS, CONTRACT_VERSION, PUBLISHED, SCENARIOS, SCHEMAS, extra_buyers_per_1000, fold_counts,
                  null_qini, two_prop_ci, verdict)

ROOT = Path(__file__).resolve().parent

# ----------------------------- synthetic result tables (tests only) -----------------------------
APPROACHES = {
    "S-learner": ["LR", "RF", "XGB"], "T-learner": ["LR", "RF", "XGB"],
    "X-learner": ["LR", "RF", "XGB"], "R-learner": ["LR", "RF", "XGB"],
    "Uplift forest": ["KL", "ED", "CHI"], "Causal forest": ["default"],
    "Response model": ["LR"], "Purchase propensity": ["LR"],
}
SCEN_SKILL = {"A": 1.0, "A_prime": 0.9, "B": 0.4, "C": 0.8}
ATE = {"Men's email": 0.68, "Women's email": 0.31}
COVS = ["recency", "history", "mens", "womens", "newbie", "zip_Urban", "zip_Suburban", "channel_Web",
        "channel_Phone", "channel_Multi"]


def build():
    rng = np.random.default_rng(0)
    qini, curves, dec, pdiff, diag, bal, ov, crit = [], [], [], [], [], [], [], []
    for c in CAMPAIGNS:
        ate = ATE[c]
        for s, skill in SCEN_SKILL.items():
            k = 0
            best = {}
            rows = []
            for ap, bases in APPROACHES.items():
                for b in bases:
                    k += 1
                    q = 0.0008 * skill * (1 + 0.15 * ((k * 7) % 5)) * (ate / 0.68)
                    rows.append((ap, f"{ap} {b}", q))
            for ap, m, q in rows:
                best[ap] = max(best.get(ap, (None, -1)), (m, q), key=lambda t: t[1])
            for ap, m, q in rows:
                qini.append(dict(campaign=c, scenario=s, approach=ap, model=m, qini=q, ci_lo=q - 4e-4, ci_hi=q + 4e-4,
                                 is_best=(best[ap][0] == m), selected=(m == "S-learner XGB")))
                diag.append(dict(campaign=c, scenario=s, model=m, stability_iqr=1e-4, validation_gap=0.3,
                                 seconds_per_trial=3.0))
            for d in range(1, 11):
                u = (2.0 - 0.35 * d) * (ate / 0.68) * skill
                dec.append(dict(campaign=c, scenario=s, model="S-learner XGB", decile=d, uplift_pp=u,
                                ci_lo_pp=u - 0.9, ci_hi_pp=u + 0.9))
            x = np.arange(0, 101, 10)
            shapes = {"uplift": 1 - (1 - x / 100) ** (1 + 1.2 * skill), "response": (x / 100) ** 1.0 * 0.9 + 0.05 * np.sin(x / 15),
                      "propensity": (x / 100) ** 1.1, "ideal": np.minimum(1.0, x / 100 * 2.4)}
            for meth, shape in shapes.items():
                shape = np.clip(shape, 0, None)
                gain = ate * shape
                for xi, gi in zip(x, gain):
                    w = 0.0 if xi == 0 else 0.12 * ate
                    curves.append(dict(campaign=c, scenario=s, method=meth, model="S-learner XGB" if meth == "uplift" else meth,
                                       share_pct=int(xi), gain=gi, ci_lo=gi - w if meth != "ideal" else np.nan,
                                       ci_hi=gi + w if meth != "ideal" else np.nan))
            pdiff.append(dict(campaign=c, scenario=s, comparison="meta-learner vs forest", estimate=0.01, ci_lo=0.0,
                              ci_hi=0.02, holm_p=0.03))
            ov.append(dict(campaign=c, scenario=s, treated_kept=900, control_kept=900, treated_in_support=0.95,
                           control_in_support=0.93))
        for cov in COVS:
            bal.append(dict(campaign=c, covariate=cov, smd_randomized=0.01, smd_confounded=float(rng.uniform(0.1, 0.4)),
                            smd_matched=float(rng.uniform(0.0, 0.08))))
        crit += [dict(criterion="C1", campaign=c, estimate=0.01, ci_lo=0.005, ci_hi=0.02, threshold=0.001, precondition_met=np.nan),
                 dict(criterion="C2", campaign=c, estimate=0.06, ci_lo=np.nan, ci_hi=np.nan, threshold=0.1, precondition_met=np.nan),
                 dict(criterion="C3", campaign=c, estimate=0.002, ci_lo=0.0005, ci_hi=0.004, threshold=0.001,
                      precondition_met=True, recovered_share=0.6),
                 dict(criterion="C4", campaign=c, estimate=0.5, ci_lo=-0.1, ci_hi=1.2, threshold=0.2, precondition_met=np.nan)]
    return dict(qini_results=qini, qini_curves=curves, decile_uplift=dec, paired_differences=pdiff,
                diagnostics=diag, balance=bal, overlap=ov, criteria_results=crit)


def write(folder):
    for name, rows in build().items():
        pd.DataFrame(rows).to_csv(folder / f"{name}.csv", index=False)


@pytest.fixture
def fake_outputs(tmp_path, monkeypatch):
    write(tmp_path)
    monkeypatch.setenv("UPLIFT_OUTPUTS", str(tmp_path))
    return tmp_path


@pytest.fixture
def empty_outputs(tmp_path, monkeypatch):
    monkeypatch.setenv("UPLIFT_OUTPUTS", str(tmp_path))
    return tmp_path


def run(campaign="Men's email", scenario="A") -> AppTest:
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=120)
    at.session_state["campaign"] = campaign
    at.session_state["scenario"] = scenario
    return at.run()


def text(at) -> str:
    return " ".join([m.value for m in at.markdown] + [c.value for c in at.caption])


# ----------------------------- statistics -----------------------------
def test_interval_contains_estimate():
    r = two_prop_ci(0.0125, 21307, 0.0057, 21306)
    assert r["lo"] < r["diff"] < r["hi"] and r["lo"] > 0


def test_extra_buyers_match_published_uplift():
    d = extra_buyers_per_1000(PUBLISHED).set_index("campaign")
    assert abs(d.loc["Men's email", "per_1000"] - 6.8) < 0.1
    assert abs(d.loc["Women's email", "per_1000"] - 3.1) < 0.1


def test_fold_counts_ten_folds():
    f = fold_counts(PUBLISHED, "Men's email", 10)
    assert 4200 < f["n_fold"] < 4300 and 11 < f["control_buyers"] < 13 and 26 < f["emailed_buyers"] < 28
    assert f["top30_pooled_pp"] < f["top30_single_pp"]


def test_null_qini_centered_at_zero():
    q = null_qini(2000, 0.01, 0.005, sims=300)
    assert abs(q.mean()) < 3 * q.std() / np.sqrt(300)


def test_verdict_rules():
    assert verdict(1, 0.5, 1.5, 0.2) == "met"
    assert verdict(0.1, -0.2, 0.0, 0.2) == "not_met"
    assert verdict(0.5, -0.1, 1.2, 0.2) == "inconclusive"
    assert verdict(0.5, np.nan, np.nan, 0.2) == "pending"
    assert verdict(0.5, 0.1, 0.9, np.nan) == "pending"
    assert verdict(0.05, np.nan, np.nan, 0.1, "lower") == "met"
    assert verdict(0.15, np.nan, np.nan, 0.1, "lower") == "not_met"


# ----------------------------- layout and contract -----------------------------
def test_layout_references_only_registered_panels():
    assert set(app.panel_names()) <= set(app.PANELS)


def test_every_registered_panel_is_placed_and_kpis_cover_all_criteria():
    counts = Counter(app.panel_names())
    assert all(counts[p] >= 1 for p in app.PANELS)
    kpis = [n for row in app.LAYOUT for n, _ in row.panels if n.startswith("kpi:")]
    assert sorted(kpis) == ["kpi:C1", "kpi:C2", "kpi:C3", "kpi:C4"]


def test_contract_lists_the_agreed_files():
    assert CONTRACT_VERSION == 2
    assert set(SCHEMAS) == {"data_summary", "criteria_results", "qini_curves", "qini_results", "decile_uplift",
                            "paired_differences", "diagnostics", "balance", "overlap"}


# ----------------------------- rendering -----------------------------
def test_empty_state_renders_without_errors_and_shows_pending(empty_outputs):
    at = run()
    assert not at.exception and not at.error
    t = text(at)
    assert t.count("Pending") >= 4 and "Met" not in t.replace("Pending", "")


@pytest.mark.parametrize("campaign", ["Men's email", "Women's email"])
@pytest.mark.parametrize("scenario", list(SCENARIOS))
def test_full_data_renders_in_every_state(campaign, scenario, fake_outputs):
    at = run(campaign, scenario)
    assert not at.exception and not at.error


def test_verdict_badges_with_data(fake_outputs):
    t = text(run())
    assert "✅ Met" in t and "❓ Inconclusive" in t


def test_no_recovery_claim_when_precondition_fails(fake_outputs):
    p = fake_outputs / "criteria_results.csv"
    df = pd.read_csv(p)
    df.loc[df.criterion == "C3", "precondition_met"] = False
    df.to_csv(p, index=False)
    assert "No recovery claim" in text(run())


def test_missing_columns_show_an_error_not_a_crash(fake_outputs):
    p = fake_outputs / "balance.csv"
    pd.read_csv(p).drop(columns=["smd_matched"]).to_csv(p, index=False)
    at = run()
    assert not at.exception and any("smd_matched" in e.value for e in at.error)


@pytest.mark.parametrize("button", ["btn_def", "btn_pair", "btn_diag", "btn_lim"])
def test_detail_dialogs_open(button, fake_outputs):
    at = run()
    next(b for b in at.button if b.key == button).click()
    at.run()
    assert not at.exception
