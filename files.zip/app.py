"""Uplift dashboard: one screen, one script.

Layout is the LAYOUT table below. Panels are the functions above it. Data and statistics live in data.py.
To redesign: edit LAYOUT (rows, heights, order, widths) and bump DESIGN_VERSION in data.py.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from data import (BADGES, CAMPAIGNS, CHROME_PX, CRITERIA, CURRENT_SPRINT, DESIGN_VERSION, METHODS, PUBLISHED,
                  RANDOM_STYLE, SCENARIO_SHORT, SCENARIOS, SCHEMAS, SMD_LIMIT, THEME, TOTAL_SPRINTS, arm_rates,
                  exists, fold_counts, load, null_qini, verdict)

# ============================ Helpers ============================
PLOT_CONFIG = {"displayModeBar": False}


@dataclass(frozen=True)
class Ctx:
    """What a panel needs to know about where it is drawn."""
    campaign: str
    scenario: str
    height: int          # pixel height of the panel container
    name: str = ""       # panel name, used to key its chart

    @property
    def chart_h(self) -> int:
        return max(60, self.height - CHROME_PX)


def get_campaign() -> str:
    return st.session_state.get("campaign", CAMPAIGNS[0])


def get_scenario() -> str:
    return st.session_state.get("scenario", "A")


def summary_table() -> pd.DataFrame:
    s = load("data_summary")
    return s if s is not None else PUBLISHED


def selected_model(campaign: str) -> str | None:
    q = load("qini_results")
    if q is None:
        return None
    s = q[(q.campaign == campaign) & (q.selected.astype(str).str.lower() == "true")]
    return None if s.empty else str(s.model.iloc[0])


def panel_title(title: str, sub: str = "") -> None:
    sub_html = f" <span style='color:{THEME['muted']};font-size:0.8rem'>{sub}</span>" if sub else ""
    # <p> (not <div>): Streamlit's markdown container pulls its last child up by 1rem unless it is a <p>
    st.markdown(f"<p style='line-height:1.2'><b>{title}</b>{sub_html}</p>", unsafe_allow_html=True)


def hex_to_rgba(color: str, alpha: float) -> str:
    c = color.lstrip("#")
    return f"rgba({int(c[0:2], 16)},{int(c[2:4], 16)},{int(c[4:6], 16)},{alpha})"


def show(fig: go.Figure, h: int, key: str, legend: bool = False) -> None:
    """Apply the compact house style and draw."""
    fig.update_layout(height=h, margin=dict(l=4, r=8, t=4, b=4), font=dict(size=11), showlegend=legend,
                      legend=dict(orientation="h", y=1.12, x=0, font=dict(size=10)),
                      plot_bgcolor=fig.layout.plot_bgcolor or "white", paper_bgcolor="rgba(0,0,0,0)")
    fig.update_xaxes(automargin=True, gridcolor="#E6E9EF", zeroline=False)
    fig.update_yaxes(automargin=True, gridcolor="#E6E9EF", zeroline=False)
    st.plotly_chart(fig, config=PLOT_CONFIG, key=key)


def pending_fig(h: int, sprint: int, xlabel: str = "", ylabel: str = "") -> go.Figure:
    """Empty frame with axes labels, the same footprint the real chart will fill."""
    fig = go.Figure()
    fig.update_layout(xaxis=dict(title=xlabel, showticklabels=False, showgrid=False, zeroline=False),
                      yaxis=dict(title=ylabel, showticklabels=False, showgrid=False, zeroline=False),
                      plot_bgcolor=THEME["frame"],
                      annotations=[dict(text=f"Pending · Sprint {sprint}", x=0.5, y=0.5, xref="paper", yref="paper",
                                        showarrow=False, font=dict(size=14, color=THEME["muted"]))])
    return fig


def interval_bar(est, lo, hi, thr, h: int = 46, sprint: int | None = None) -> go.Figure:
    """Estimate with its interval against the threshold (a small bullet graph)."""
    fig = go.Figure()
    vals = [v for v in (est, lo, hi, thr) if v is not None and not pd.isna(v)]
    if sprint is not None or not vals:
        fig.update_layout(xaxis=dict(visible=False), yaxis=dict(visible=False), plot_bgcolor=THEME["frame"],
                          annotations=[dict(text=f"Sprint {sprint}" if sprint else "", x=0.5, y=0.5, xref="paper",
                                            yref="paper", showarrow=False, font=dict(size=11, color=THEME["muted"]))])
        return fig
    span = (max(vals + [0]) - min(vals + [0])) or 1.0
    fig.update_xaxes(range=[min(vals + [0]) - 0.2 * span, max(vals + [0]) + 0.2 * span], tickfont=dict(size=9),
                     nticks=5)
    fig.update_yaxes(visible=False, range=[-1, 1])
    fig.add_vline(x=0, line_color="#B8BEC9", line_width=1)
    if lo is not None and hi is not None and not (pd.isna(lo) or pd.isna(hi)):
        fig.add_scatter(x=[lo, hi], y=[0, 0], mode="lines", line=dict(color=THEME["primary"], width=6),
                        hoverinfo="skip")
    if est is not None and not pd.isna(est):
        fig.add_scatter(x=[est], y=[0], mode="markers", marker=dict(color=THEME["ink"], size=10),
                        hoverinfo="skip")
    if thr is not None and not pd.isna(thr):
        fig.add_vline(x=thr, line_color=THEME["danger"], line_dash="dot", line_width=2)
    return fig


def criterion_result(criterion: str, campaign: str) -> dict:
    """Verdict and numbers for one criterion, from criteria_results.csv (or pending)."""
    out = {"verdict": "pending", "estimate": None, "lo": None, "hi": None, "threshold": None,
           "recovered_share": None}
    df = load("criteria_results")
    if df is None:
        return out
    row = df[(df.criterion == criterion) & (df.campaign == campaign)]
    if row.empty:
        return out
    r = row.iloc[0]
    out.update(estimate=r.estimate, lo=r.ci_lo, hi=r.ci_hi, threshold=r.threshold,
               recovered_share=r.get("recovered_share"))
    if criterion == "C3" and str(r.precondition_met).lower() == "false":
        out["verdict"] = "no_claim"
    else:
        out["verdict"] = verdict(r.estimate, r.ci_lo, r.ci_hi, r.threshold, CRITERIA[criterion]["direction"])
    return out


@st.cache_data(show_spinner=False)
def _noise_p95(n: int, base: float, ate: float) -> float:
    return float(np.quantile(null_qini(n, base, ate, 300), 0.95))


def noise_floor(campaign: str) -> float:
    """95th percentile Qini of a ranking with no skill, at the 10-fold test-slice size."""
    s = summary_table()
    c, k = arm_rates(s, campaign)
    n = fold_counts(s, campaign, 10)["n_fold"]
    return _noise_p95(n, float(k.conversion_rate), float(c.conversion_rate - k.conversion_rate))


def scenario_label(key: str) -> str:
    return SCENARIOS.get(key, key)


# ============================ Pop-ups (details on demand) ============================
def _pending(name: str) -> None:
    st.info(f"Pending: arrives in Sprint {SCHEMAS[name]['sprint']} (`outputs/{name}.csv`).")


@st.dialog("Definitions", width="large")
def definitions() -> None:
    st.markdown(
        "- **Uplift:** how much an email changes a customer's chance of buying.\n"
        "- **Qini score:** area between the ranking's cumulative extra-purchase curve and the random line. "
        "Higher is better.\n"
        "- **Luck level (noise floor):** the 95th percentile Qini of a ranking with no skill, at the size of one "
        "test slice. A real result has to beat it.\n"
        "- **Selected model:** the model chosen on randomized data. Charts for it carry the same model through "
        "every scenario.\n"
        "- **SMD:** balance score for one characteristic. Below 0.1 counts as well balanced.\n"
        "- **Overlap:** share of customers where both emailed and non-emailed customers exist.\n"
        "- **Paired difference:** difference between two methods on the same customers, with a 95% bootstrap interval.")
    st.markdown("**Verdict rule** (from the 95% interval of the quantity tested)")
    st.table({"Verdict": ["Met", "Not met", "Inconclusive", "Pending"],
              "Rule": ["Lower bound above the threshold", "Upper bound below the threshold",
                       "Interval straddles the threshold", "Result not yet computed"]})


@st.dialog("Paired differences", width="large")
def paired(campaign: str, scenario: str) -> None:
    d = load("paired_differences")
    if d is None:
        _pending("paired_differences")
        return
    d = d[(d.campaign == campaign) & (d.scenario == scenario)]
    st.caption(f"{campaign} · {SCENARIOS[scenario]}. Same customers in both methods. Holm-corrected p-values are secondary.")
    st.dataframe(d.drop(columns=["campaign", "scenario"]), hide_index=True)


@st.dialog("Diagnostics", width="large")
def diagnostics(campaign: str, scenario: str) -> None:
    st.caption(f"{campaign} · {SCENARIOS[scenario]}")
    st.markdown("**All configurations (Qini)**")
    q = load("qini_results")
    if q is None:
        _pending("qini_results")
    else:
        st.dataframe(q[(q.campaign == campaign) & (q.scenario == scenario)].drop(columns=["campaign", "scenario"]),
                     hide_index=True)
    st.markdown("**Stability, overfitting, speed**")
    g = load("diagnostics")
    if g is None:
        _pending("diagnostics")
    else:
        st.dataframe(g[(g.campaign == campaign) & (g.scenario == scenario)].drop(columns=["campaign", "scenario"]),
                     hide_index=True)
    st.markdown("**Matched sample and overlap**")
    o = load("overlap")
    if o is None:
        _pending("overlap")
    else:
        st.dataframe(o[o.campaign == campaign].drop(columns="campaign"), hide_index=True)
    st.markdown("**Result files**")
    st.dataframe({"File": [f"{k}.csv" for k in SCHEMAS], "Sprint": [v["sprint"] for v in SCHEMAS.values()],
                  "Status": ["present" if exists(k) else "pending" for k in SCHEMAS]}, hide_index=True)


@st.dialog("Limits", width="large")
def limits(campaign: str) -> None:
    s = summary_table()
    f = fold_counts(s, campaign, 10)
    st.markdown("**Signal budget** (10 test slices)")
    a, b, c, d = st.columns(4)
    a.metric("Customers per slice", f"{f['n_fold']:,}")
    b.metric("Buyers, no email", f"{f['control_buyers']:.0f}")
    c.metric("Buyers, emailed", f"{f['emailed_buyers']:.0f}")
    d.metric("Luck-level Qini", f"{noise_floor(campaign):.4f}")
    st.caption(f"Top-30% uplift in one slice has a 95% interval of about ±{f['top30_single_pp']:.2f} pp, "
               f"or ±{f['top30_pooled_pp']:.2f} pp with all slices pooled. Average effect: {f['avg_effect_pp']:.2f} pp. "
               "Based on group sizes and rates, for a group with average response.")
    st.markdown(
        "**Limits**\n"
        "- **Few buyers.** Small differences between methods may be impossible to separate from luck.\n"
        "- **The bias is simulated.** Real targeting rules are messier.\n"
        "- **Matching only sees what we measure.** Unmeasured factors are not tested here.\n"
        "- **Seven customer characteristics.** Other factors may matter.\n"
        "- **Group-level evidence.** Individual effects cannot be observed.\n"
        "- **Purchases, not profit.** Costs and margins are not modeled.\n"
        "- **One retailer, one two-week window, 2008.**\n"
        "- **Matching discards data.** The fair-size check (A′) quantifies this.")


# ============================ Panels ============================
def kpi(ctx: Ctx, cid: str) -> None:
    """One success criterion: title, value, verdict badge, interval against threshold, status line."""
    spec, r = CRITERIA[cid], criterion_result(cid, ctx.campaign)
    scale, d = spec["scale"], spec["digits"]
    has_value = r["estimate"] is not None and not pd.isna(r["estimate"]) and r["verdict"] != "no_claim"
    st.markdown(f"<p style='line-height:1.2'><b>{cid} · {spec['title']}</b></p>", unsafe_allow_html=True)
    value = f"{r['estimate'] * scale:.{d}f}" if has_value else "—"
    st.markdown(f"<p style='display:flex;justify-content:space-between;align-items:center;line-height:1.1'>"
                f"<span style='font-size:1.6rem;font-weight:700'>{value}</span>"
                f"<b style='font-size:0.9rem'>{BADGES[r['verdict']]}</b></p>", unsafe_allow_html=True)

    def sc(v):
        return None if v is None or pd.isna(v) else v * scale

    pending = r["verdict"] in ("pending", "no_claim")
    show(interval_bar(sc(r["estimate"]), sc(r["lo"]), sc(r["hi"]), sc(r["threshold"]), 36,
                      sprint=spec["sprint"] if r["verdict"] == "pending" else None), 36, ctx.name)
    if r["verdict"] == "pending":
        note = f"{spec['text']}"
    elif r["verdict"] == "no_claim":
        note = "Bias did not clearly hurt ranking, so no recovery is claimed"
    else:
        thr = sc(r["threshold"])
        note = f"{spec['unit']} · threshold {thr:.{d}f}" if thr is not None else f"{spec['unit']} · threshold not set"
        if cid == "C3" and r["recovered_share"] is not None and not pd.isna(r["recovered_share"]):
            note += f" · {r['recovered_share']:.0%} of loss recovered"
    st.markdown(f"<p style='color:{THEME['muted']};font-size:0.75rem;line-height:1.2'>{note}</p>",
                unsafe_allow_html=True)


def qini_curve(ctx: Ctx, arg: str = "") -> None:
    """Hero chart: cumulative extra purchases by share emailed, with the scenario toggle."""
    head, toggle = st.columns([5, 3])
    with toggle:
        st.radio("Scenario", list(SCENARIOS), key="scenario", horizontal=True, label_visibility="collapsed",
                 format_func=SCENARIO_SHORT.get)
    scenario = st.session_state.get("scenario", ctx.scenario)
    df = load("qini_curves")
    model = None
    if df is not None:
        d = df[(df.campaign == ctx.campaign) & (df.scenario == scenario)]
        up = d[d.method == "uplift"]
        model = up.model.iloc[0] if not up.empty else None
    with head:
        panel_title("Does uplift ranking beat luck?", f"{scenario_label(scenario)}" + (f" · {model}" if model else ""))
    h = ctx.chart_h - 6
    if df is None or d.empty:
        show(pending_fig(h, 3, "Share of customers emailed (%)", "Extra purchases (pp)"), h, ctx.name)
        return
    fig = go.Figure()
    for key, (label, color, dash) in METHODS.items():
        m = d[d.method == key].sort_values("share_pct")
        if m.empty:
            continue
        fig.add_scatter(x=m.share_pct, y=m.gain, name=label, mode="lines",
                        line=dict(color=color, dash=dash, width=2.5 if key == "uplift" else 1.6))
        if key != "ideal" and m.ci_lo.notna().all():
            fig.add_scatter(x=list(m.share_pct) + list(m.share_pct[::-1]), y=list(m.ci_hi) + list(m.ci_lo[::-1]),
                            fill="toself", fillcolor=hex_to_rgba(color, 0.14), line=dict(width=0),
                            showlegend=False, hoverinfo="skip")
    if not up.empty:
        end = float(up.sort_values("share_pct").gain.iloc[-1])
        fig.add_scatter(x=[0, 100], y=[0, end], name=RANDOM_STYLE[0], mode="lines",
                        line=dict(color=RANDOM_STYLE[1], dash=RANDOM_STYLE[2], width=1.6))
    fig.update_xaxes(title_text="Share of customers emailed (%)", title_font=dict(size=10))
    fig.update_yaxes(title_text="Extra purchases (pp)", title_font=dict(size=10))
    show(fig, h, ctx.name, legend=True)


def model_ranking(ctx: Ctx, arg: str = "") -> None:
    """Best configuration per approach, with intervals and the noise floor."""
    panel_title("Which approach ranks best?", scenario_label(ctx.scenario))
    q = load("qini_results")
    h = ctx.chart_h
    if q is None:
        show(pending_fig(h, 3, "Qini score (higher is better)"), h, ctx.name)
        return
    d = q[(q.campaign == ctx.campaign) & (q.scenario == ctx.scenario) &
          (q.is_best.astype(str).str.lower() == "true")].sort_values("qini")
    if d.empty:
        show(pending_fig(h, 3, "Qini score (higher is better)"), h, ctx.name)
        return
    sel = d.selected.astype(str).str.lower() == "true"
    fig = go.Figure(go.Scatter(
        x=d.qini, y=d.approach, mode="markers", hovertext=d.model,
        marker=dict(size=[12 if s else 8 for s in sel], symbol=["diamond" if s else "circle" for s in sel],
                    color=THEME["primary"]),
        error_x=dict(type="data", symmetric=False, array=d.ci_hi - d.qini, arrayminus=d.qini - d.ci_lo)))
    fig.add_vline(x=noise_floor(ctx.campaign), line_dash="dot", line_color=THEME["danger"],
                  annotation_text="luck level", annotation_font_size=10, annotation_position="top")
    fig.update_xaxes(title_text="Qini score (◆ = selected model)", title_font=dict(size=10))
    fig.update_yaxes(dtick=1, tickfont=dict(size=10))
    show(fig, h, ctx.name)


def scenario_recovery(ctx: Ctx, arg: str = "") -> None:
    """Qini of the selected model across scenarios A, A′, B and C."""
    model = selected_model(ctx.campaign)
    panel_title("Bias hurts, matching repairs?", model or "")
    q, h = load("qini_results"), ctx.chart_h
    if q is None:
        show(pending_fig(h, 4, "", "Qini score"), h, ctx.name)
        return
    d = q[(q.campaign == ctx.campaign) & (q.selected.astype(str).str.lower() == "true")]
    d = d.set_index("scenario").reindex(list(SCENARIOS)).dropna(subset=["qini"]).reset_index()
    fig = go.Figure(go.Scatter(
        x=[SCENARIOS[s].replace(": ", "<br>") for s in d.scenario], y=d.qini,
        mode="markers", marker=dict(size=11, color=THEME["primary"]),
        error_y=dict(type="data", symmetric=False, array=d.ci_hi - d.qini, arrayminus=d.qini - d.ci_lo)))
    if "A" in set(d.scenario):
        fig.add_hline(y=float(d[d.scenario == "A"].qini.iloc[0]), line_dash="dot", line_color=THEME["muted"],
                      annotation_text="randomized benchmark", annotation_font_size=10)
    if criterion_result("C3", ctx.campaign)["verdict"] == "no_claim":
        fig.add_annotation(text="Bias did not clearly hurt ranking: no recovery claim", xref="paper", yref="paper",
                           x=0.5, y=1.0, showarrow=False, font=dict(size=10, color=THEME["danger"]))
    fig.update_yaxes(title_text="Qini score", title_font=dict(size=10))
    show(fig, h, ctx.name)


def balance(ctx: Ctx, arg: str = "") -> None:
    """Covariate balance (absolute SMD) before and after matching."""
    panel_title("Are the groups alike?", "after matching")
    b, h = load("balance"), ctx.chart_h
    if b is None:
        show(pending_fig(h, 4, "Absolute SMD"), h, ctx.name)
        return
    d = b[b.campaign == ctx.campaign].sort_values("smd_confounded")
    fig = go.Figure()
    for col, name, sym, color in [("smd_confounded", "Before", "circle-open", THEME["danger"]),
                                  ("smd_matched", "After", "circle", THEME["primary"])]:
        fig.add_scatter(x=d[col], y=d.covariate, mode="markers", name=name,
                        marker=dict(symbol=sym, size=8, color=color, line=dict(width=2, color=color)))
    fig.add_vline(x=SMD_LIMIT, line_dash="dot", line_color=THEME["muted"])
    fig.update_xaxes(title_text="Absolute SMD · ○ before ● after (limit 0.1)", title_font=dict(size=10))
    fig.update_yaxes(tickfont=dict(size=8), dtick=1)
    show(fig, h, ctx.name)


def decile(ctx: Ctx, arg: str = "") -> None:
    """Observed uplift in each tenth of the ranking, best to worst."""
    d_all, model = load("decile_uplift"), selected_model(ctx.campaign)
    panel_title("Does uplift fall best to worst?", scenario_label(ctx.scenario))
    h = ctx.chart_h
    if d_all is None:
        show(pending_fig(h, 3, "Decile (1 = highest predicted uplift)", "Uplift (pp)"), h, ctx.name)
        return
    d = d_all[(d_all.campaign == ctx.campaign) & (d_all.scenario == ctx.scenario)]
    model = model if model in set(d.model) else (d.model.iloc[0] if not d.empty else None)
    d = d[d.model == model].sort_values("decile")
    if d.empty:
        show(pending_fig(h, 3, "Decile (1 = highest predicted uplift)", "Uplift (pp)"), h, ctx.name)
        return
    fig = go.Figure(go.Bar(
        x=d.decile, y=d.uplift_pp, marker_color=[THEME["primary"] if v >= 0 else THEME["danger"] for v in d.uplift_pp],
        error_y=dict(type="data", symmetric=False, array=d.ci_hi_pp - d.uplift_pp, arrayminus=d.uplift_pp - d.ci_lo_pp)))
    fig.update_xaxes(title_text="Decile (1 = best)", title_font=dict(size=10), dtick=1)
    fig.update_yaxes(title_text="Uplift (pp)", title_font=dict(size=10))
    show(fig, h, ctx.name)


def header(ctx: Ctx, arg: str = "") -> None:
    title, chip, control = st.columns([5, 3, 4])
    title.markdown("<p style='font-size:1.45rem;font-weight:700;line-height:1.6'>Who buys because of an email?</p>",
                   unsafe_allow_html=True)
    chip.markdown(f"<p style='color:{THEME['muted']};padding-top:10px;font-size:0.85rem'>"
                  f"Sprint {CURRENT_SPRINT} of {TOTAL_SPRINTS} · design v{DESIGN_VERSION}</p>", unsafe_allow_html=True)
    control.radio("Campaign", CAMPAIGNS, key="campaign", horizontal=True, label_visibility="collapsed")


def footer(ctx: Ctx, arg: str = "") -> None:
    s = summary_table()
    n = int(s.n.sum())
    ctrl = arm_rates(s, ctx.campaign)[1]
    buyers = ctrl.n * ctrl.conversion_rate
    context, b1, b2, b3, b4 = st.columns([7, 1, 1.5, 1.2, 0.8])
    context.markdown(f"<p style='color:{THEME['muted']};font-size:0.8rem;padding-top:6px'>"
                     f"{n:,} customers · about {buyers:.0f} buyers with no email · Qini = area above the random line"
                     f"</p>", unsafe_allow_html=True)
    if b1.button("Definitions", key="btn_def"):
        definitions()
    if b2.button("Paired differences", key="btn_pair"):
        paired(ctx.campaign, ctx.scenario)
    if b3.button("Diagnostics", key="btn_diag"):
        diagnostics(ctx.campaign, ctx.scenario)
    if b4.button("Limits", key="btn_lim"):
        limits(ctx.campaign)


# ============================ Layout: the whole screen as one table ============================
PANELS = {
    "header": header, "kpi": kpi, "qini_curve": qini_curve, "model_ranking": model_ranking,
    "scenario_recovery": scenario_recovery, "balance": balance, "decile": decile, "footer": footer,
}


@dataclass(frozen=True)
class Row:
    height: int      # pixel height of the row
    panels: tuple    # (panel name, relative width); a name may carry an argument, e.g. "kpi:C1"
    border: bool = True


LAYOUT = (
    Row(48, (("header", 1),), border=False),
    Row(160, (("kpi:C1", 1), ("kpi:C2", 1), ("kpi:C3", 1), ("kpi:C4", 1))),
    Row(246, (("qini_curve", 1), ("model_ranking", 1))),
    Row(236, (("scenario_recovery", 2), ("balance", 1), ("decile", 1))),
    Row(46, (("footer", 1),), border=False),
)


def panel_names(layout=LAYOUT) -> list[str]:
    return [name.split(":")[0] for row in layout for name, _ in row.panels]


def run_panel(name: str, ctx: Ctx) -> None:
    key, _, arg = name.partition(":")
    try:
        PANELS[key](ctx, arg)
    except Exception as e:  # one broken panel must not take the dashboard down
        st.error(f"Panel '{name}' failed: {e}")


def render(layout=LAYOUT) -> None:
    campaign = get_campaign()
    for row in layout:
        cols = st.columns([w for _, w in row.panels])
        for col, (name, _) in zip(cols, row.panels):
            with col, st.container(border=row.border, height=row.height):
                scenario = st.session_state.get("scenario", "A")
                run_panel(name, Ctx(campaign, scenario, row.height, name))


def main() -> None:
    st.set_page_config(page_title="Uplift: who buys because of an email?", page_icon=":material/target:",
                       layout="wide", initial_sidebar_state="collapsed")
    st.markdown(
        """<style>
        .block-container {padding: 0.5rem 1rem 0.2rem 1rem; max-width: 100%;}
        [data-testid="stHeader"] {display: none;}
        [data-testid="stVerticalBlock"] {gap: 0.35rem;}
        </style>""",
        unsafe_allow_html=True,
    )
    render()


if __name__ == "__main__":
    main()
