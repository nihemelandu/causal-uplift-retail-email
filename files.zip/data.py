"""Constants, the result-file contract, and the statistics behind the dashboard.

Everything a redesign might tweak (colors, labels, design version) is in section 1.
The result files the dashboard reads are described in section 2 (CONTRACT_VERSION).
"""
from __future__ import annotations

import os
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st

# ============================ 1. Settings ============================
ROOT = Path(__file__).resolve().parent

DESIGN_VERSION = "1.0"      # bump on every redesign
CONTRACT_VERSION = 2        # bump when a result-file schema changes
CURRENT_SPRINT, TOTAL_SPRINTS = 1, 6


def outputs_dir() -> Path:
    """Folder the dashboard reads. Override with UPLIFT_OUTPUTS (used by tests)."""
    return Path(os.environ.get("UPLIFT_OUTPUTS", ROOT / "outputs"))


THEME = dict(primary="#2B5FD9", muted="#7A808A", danger="#D9482B", warn="#E08A1E",
             good="#2E8B57", frame="#F4F6FA", ink="#1B2430")

CAMPAIGNS = ["Men's email", "Women's email"]
SCENARIOS = {"A": "A: Randomized", "A_prime": "A′: Fair-size check", "B": "B: Biased",
             "C": "C: Biased + matching"}
SCENARIO_SHORT = {"A": "A", "A_prime": "A′", "B": "B", "C": "C"}

# method key -> (label, color, dash). The same style is used for a method on every chart.
METHODS = {
    "uplift": ("Uplift model", THEME["primary"], "solid"),
    "response": ("Likely to buy (response)", THEME["warn"], "dash"),
    "propensity": ("Purchase propensity", THEME["good"], "dashdot"),
    "ideal": ("Ideal ranking", THEME["ink"], "longdash"),
}
RANDOM_STYLE = ("Random (luck level)", THEME["muted"], "dot")

# criterion -> display spec. scale/digits control how the headline value is shown.
CRITERIA = {
    "C1": dict(title="Standard tools compete", sprint=3, direction="higher", scale=1, digits=4,
               unit="Qini points", text="Best meta-learner minus best specialist forest"),
    "C2": dict(title="Matching balances groups", sprint=4, direction="lower", scale=1, digits=3,
               unit="largest |SMD|", text="Largest balance score after matching (limit 0.1)"),
    "C3": dict(title="Damage and repair", sprint=4, direction="higher", scale=1, digits=4,
               unit="Qini points", text="Qini gain from matching over unadjusted"),
    "C4": dict(title="Persuasion beats likelihood", sprint=3, direction="higher", scale=10, digits=1,
               unit="per 1,000 emailed", text="Extra purchases per 1,000 emailed, top 30%"),
}

BADGES = {"met": "✅ Met", "not_met": "❌ Not met", "inconclusive": "❓ Inconclusive",
          "pending": "⏳ Pending", "no_claim": "➖ No recovery claim"}

SMD_LIMIT = 0.1
CHROME_PX = 76   # vertical space a bordered panel spends on padding, border, title line and gaps


# ============================ 2. Result-file contract ============================
# The dashboard only reads CSV files from outputs/. Each file is written by the pipeline in the sprint
# named below. While a file is missing, panels show a labelled placeholder, never numbers.
SCHEMAS = {
    "data_summary": dict(sprint=2, columns=["group", "n", "visit_rate", "conversion_rate"],
                         note="One row per arm: 'Men's email', 'Women's email', 'Control (no email)'."),
    "criteria_results": dict(sprint=3, columns=["criterion", "campaign", "estimate", "ci_lo", "ci_hi", "threshold",
                                                "precondition_met"],
                             note="C1-C4, one row per criterion and campaign. C1: Qini difference. C2: largest |SMD| "
                                  "(no interval). C3: Qini gain of matched over unadjusted, precondition_met True/False, "
                                  "optional recovered_share (0-1). C4: top-30% uplift difference in percentage points."),
    "qini_curves": dict(sprint=3, columns=["campaign", "scenario", "method", "model", "share_pct", "gain", "ci_lo", "ci_hi"],
                        note="Cumulative incremental purchases (percentage points of all customers) by share emailed. "
                             "method: uplift (the selected model), response, propensity, ideal."),
    "qini_results": dict(sprint=3, columns=["campaign", "scenario", "approach", "model", "qini", "ci_lo", "ci_hi",
                                            "is_best", "selected"],
                         note="Metric M1, all configurations. is_best marks the best model within each approach; "
                              "selected marks the model chosen on randomized data."),
    "decile_uplift": dict(sprint=3, columns=["campaign", "scenario", "model", "decile", "uplift_pp", "ci_lo_pp", "ci_hi_pp"],
                          note="Metric M9. decile 1 = highest predicted uplift."),
    "paired_differences": dict(sprint=3, columns=["campaign", "scenario", "comparison", "estimate", "ci_lo", "ci_hi",
                                                  "holm_p"],
                               note="Metric M3. Differences between methods on the same customers."),
    "diagnostics": dict(sprint=3, columns=["campaign", "scenario", "model", "stability_iqr", "validation_gap",
                                           "seconds_per_trial"],
                        note="Metrics M8, M10, M11."),
    "balance": dict(sprint=4, columns=["campaign", "covariate", "smd_randomized", "smd_confounded", "smd_matched"],
                    note="Metric M4. Absolute SMD per encoded covariate level."),
    "overlap": dict(sprint=4, columns=["campaign", "scenario", "treated_kept", "control_kept", "treated_in_support",
                                       "control_in_support"],
                    note="Metric M7. Shares are between 0 and 1."),
}


@st.cache_data(show_spinner=False)
def _read(path: str, mtime: float) -> pd.DataFrame:
    return pd.read_csv(path)


def exists(name: str) -> bool:
    return (outputs_dir() / f"{name}.csv").exists()


def load(name: str) -> pd.DataFrame | None:
    """Return the result table, or None if the file does not exist yet."""
    path = outputs_dir() / f"{name}.csv"
    if not path.exists():
        return None
    df = _read(str(path), path.stat().st_mtime)
    missing = [c for c in SCHEMAS[name]["columns"] if c not in df.columns]
    if missing:
        st.error(f"`outputs/{name}.csv` is missing columns: {', '.join(missing)}")
        return None
    return df


# ============================ 3. Statistics ============================
SOURCE = "Radcliffe (2008), Tables 1, 2 and 7"

PUBLISHED = pd.DataFrame({
    "group": ["Men's email", "Women's email", "Control (no email)"],
    "n": [21307, 21387, 21306],
    "visit_rate": [0.1828, 0.1514, 0.1062],
    "conversion_rate": [0.0125, 0.0088, 0.0057],
})


def two_prop_ci(p1, n1, p0, n0, z=1.96):
    diff = p1 - p0
    se = float(np.sqrt(p1 * (1 - p1) / n1 + p0 * (1 - p0) / n0))
    return {"diff": diff, "se": se, "lo": diff - z * se, "hi": diff + z * se}


def arm_rates(summary: pd.DataFrame, campaign: str):
    """Return (campaign row, control row) from a group summary table."""
    ctrl = summary[summary.group.str.startswith("Control")].iloc[0]
    camp = summary[summary.group == campaign].iloc[0]
    return camp, ctrl


def extra_buyers_per_1000(summary: pd.DataFrame, metric: str = "conversion_rate") -> pd.DataFrame:
    rows = []
    for campaign in ("Men's email", "Women's email"):
        c, k = arm_rates(summary, campaign)
        r = two_prop_ci(c[metric], int(c.n), k[metric], int(k.n))
        rows.append({"campaign": campaign, "per_1000": r["diff"] * 1000,
                     "lo": r["lo"] * 1000, "hi": r["hi"] * 1000, "diff_pp": r["diff"] * 100})
    return pd.DataFrame(rows)


def fold_counts(summary: pd.DataFrame, campaign: str, folds: int) -> dict:
    """Expected purchasers in one test fold, and interval half-widths for the top-30% uplift."""
    c, k = arm_rates(summary, campaign)
    n_fold = int((c.n + k.n) // folds)
    half = n_fold // 2
    out = {"n_fold": n_fold,
           "control_buyers": half * k.conversion_rate,
           "emailed_buyers": half * c.conversion_rate}

    def halfwidth(n_customers):
        m = int(0.3 * n_customers / 2)
        se = np.sqrt(c.conversion_rate * (1 - c.conversion_rate) / m + k.conversion_rate * (1 - k.conversion_rate) / m)
        return 1.96 * se * 100

    out["top30_single_pp"] = halfwidth(n_fold)
    out["top30_pooled_pp"] = halfwidth(int(c.n + k.n))
    out["avg_effect_pp"] = (c.conversion_rate - k.conversion_rate) * 100
    return out


def null_qini(n: int, base_rate: float, ate: float, sims: int = 300, seed: int = 0) -> np.ndarray:
    """Qini scores of a ranking that carries no information (the luck distribution).

    Qini(phi) = treated_buyers(phi)/N_treated - control_buyers(phi)/N_control, and the score
    is the area between this curve and the straight random-targeting line.
    """
    rng = np.random.default_rng(seed)
    out = []
    for start in range(0, sims, 100):
        m = min(100, sims - start)
        t = rng.random((m, n)) < 0.5
        y = rng.random((m, n)) < (base_rate + ate * t)
        nt = t.sum(1, keepdims=True)
        curve = np.cumsum(y & t, 1) / nt - np.cumsum(y & ~t, 1) / (n - nt)
        out.append(curve.mean(1) - 0.5 * curve[:, -1])
    return np.concatenate(out)


def verdict(estimate, lo, hi, threshold, direction="higher") -> str:
    """Verdict rule from business_understanding.md section 6."""
    vals = [estimate] if direction == "lower" else [lo, hi]
    if any(pd.isna(v) for v in vals) or pd.isna(threshold):
        return "pending"
    if direction == "lower":
        return "met" if estimate < threshold else "not_met"
    if lo > threshold:
        return "met"
    if hi < threshold:
        return "not_met"
    return "inconclusive"
